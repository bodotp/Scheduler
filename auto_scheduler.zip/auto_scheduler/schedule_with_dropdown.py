import tkinter as tk
from tkinter import *
from tkinter import ttk
import sqlite3
import random
import json
from tkinter.filedialog import asksaveasfile

#Frame1
#This file lets you search for a particular day/shift/position combo.
#Want to expand to include entire week/day
#Possibly set up program to prevent double shifts/clopens. Thinking about setting up dictionary linking shift and number, then including a don't schedule for n or n+1.
#still need to clean up windows a bit.
#currently exports schedule as rtf file. Probably want to change to either excel or whatever db company uses.

#here to make outputs of schedule json serializable
class Object:
    def toJSON(self):
        return json.dumps(
            self,
            default=lambda o: o.__dict__, 
            sort_keys=True,
            indent=4)

#name of file for auto schedule function
AUTO_SCHEDULE = "auto_schedule.rtf"

#first window
root = tk.Tk()
root.title("Scheduler")
root.geometry("1000x500")
root.eval("tk::PlaceWindow . center")


#created a def for each drop down choice
def display_choice1(choice1):
    choice1 = day_selected.get()
    
def display_choice2(choice2):
    choice2 = shift_selected.get()
    
def display_choice3(choice3):
    choice3 = position_selected.get()
    
#establish connection to databse
connection = sqlite3.connect("Schedule.db")
cursor_1 = connection.cursor()
cursor_2 = connection.cursor()
cursor_3 = connection.cursor()

#grab unique days so there is no doubling up in dropdowns
cursor_1.execute("SELECT DISTINCT day_available FROM Employee")
cursor_2.execute("SELECT DISTINCT shift_available FROM Employee")
cursor_3.execute("SELECT DISTINCT position FROM Employee")

day_available = cursor_1.fetchall()
shift_available = cursor_2.fetchall()
position = cursor_3.fetchall()

#create list for dropdown menus.
#not sure how to create custom sorts, so went into db and named days starting with numbers.
options_day=[]
for i in day_available:
    day= i[0]
    options_day.append(day)
dow=sorted(options_day)

options_shift=[]
for i in shift_available:
    shift= i[0]
    options_shift.append(shift)
shift_worked=sorted(options_shift)

options_position=[]
for i in position:
    position= i[0]
    options_position.append(position)
position_worked=sorted(options_position)

#create dropdowns
day_selected = tk.StringVar()
day_selected.set("Select Day")
#don't forget * to make days separate
drop_day = OptionMenu(root, day_selected, *dow, command=display_choice1).grid(row=0, column= 0)

shift_selected = tk.StringVar()
shift_selected.set("Select Shift")
#don't forget * to make days separate
drop_shift = OptionMenu(root, shift_selected, *shift_worked, command=display_choice2).grid(row=0, column=1)

position_selected = tk.StringVar()
position_selected.set("Select Position")
#don't forget * to make days separate
drop_position = OptionMenu(root, position_selected, *position_worked, command=display_choice3).grid(row=0, column=2)

#frame 2 is for manual entry using tkinter entry box.
def load_frame2():
    root = tk.Tk()
    root.title("Scheduler")
    root.geometry("1000x500")
    root.eval("tk::PlaceWindow . center")
    
    #here to find number of employees for given position, day, shift combo from frame 1
    cursor=connection.cursor()
    cursor.execute("SELECT * FROM Week WHERE position LIKE ? AND day LIKE ? AND shift LIKE ?", ('%' + str(position_selected.get()) + '%', '%' + str(day_selected.get()) + '%', '%' + str(shift_selected.get()) + '%'))
    needed =cursor.fetchall()
    #index list needed and create object num
    for i in needed:
        day = i[0]
        shift = i[1]
        position = i[2]
        num = i[3]
    
    #find available employees from pos, day, shift in frame 1
    cursor.execute("SELECT * FROM Employee WHERE position LIKE ? AND day_available LIKE ? AND shift_available LIKE ?", ('%' + str(position_selected.get()) + '%', '%' + str(day_selected.get()) + '%', '%' + str(shift_selected.get()) + '%'))
    available=cursor.fetchall()
    
    #use k=num to auto pull number of people needed
    #random.sample should provide unique names
    schedule=[]
#display available
#append list 'schedule' to be more user friendly
    for i in available:
        id = i[0]
        name = i[1]
        position = i[2]
        day = i[3]
        shift = i[4]
        schedule.append(name + " can work " + position + " for " + shift + " on " + day)
    for i in schedule:
        tk.Label(root, text=i).pack()
    #auto_schedule to export to different file. Currently rtf doc.
    
    my_schedule = []
    #create save file. currently exporting as rtf, probably want to change
    def writeToJSONFile(path, fileName, data):
        json.dump(data, path)
    path ='./' 
    def check():
        entry_list = ""
        for i in my_schedule:
            entry_list = entry_list + str(i.get()) + " is scheduled for " + position + " for " + shift + " on " + day + ". "
            my_label.config(text=entry_list)
        
        scheduled = Object()
        scheduled = entry_list
        files = [('JSON File', '.rtf')]
        fileName = 'Schedule'
        filepos = asksaveasfile(filetypes=files, defaultextension=json,initialfile='Schedule')
        writeToJSONFile(filepos, fileName, scheduled)
    for x in range(num):
        name_box = Entry(root)
        name_box.pack()
        my_schedule.append(name_box)
    
    generate_button = Button(root, text="Show Schedule", command=check).pack()
    close_button = Button(root, text="Back", command=root.destroy).pack()
    my_label = Label(root, text=" ")
    my_label.pack()
    root.mainloop()

#frame 3 is auto generate schedule
def load_frame3():
    
    root = tk.Tk()
    root.title("Scheduler")
    root.geometry("1000x500")
    root.eval("tk::PlaceWindow . center")

    frm = tk.Frame(root, height= 500, width= 500)
    frm.grid(row=0, column=0)
    frm.pack_propagate(False)
    
    #look for number of employees needed
    cursor=connection.cursor()
    cursor.execute("SELECT * FROM Week WHERE position LIKE ? AND day LIKE ? AND shift LIKE ?", ('%' + str(position_selected.get()) + '%', '%' + str(day_selected.get()) + '%', '%' + str(shift_selected.get()) + '%'))
    needed =cursor.fetchall()
    #index list needed and create object num
    for i in needed:
        day = i[0]
        shift = i[1]
        position = i[2]
        num = i[3]
    
    #look for available
    cursor.execute("SELECT * FROM Employee WHERE position LIKE ? AND day_available LIKE ? AND shift_available LIKE ?", ('%' + str(position_selected.get()) + '%', '%' + str(day_selected.get()) + '%', '%' + str(shift_selected.get()) + '%'))
    available=cursor.fetchall()
    #use k=num to auto pull number of people needed
    #random.sample should provide unique names
    team = random.sample(available, k=num)
    schedule=[]
#append list 'schedule' to be more user friendly
    for i in team:
        id = i[0]
        name = i[1]
        position = i[2]
        day = i[3]
        shift = i[4]
        schedule.append(name + " is scheduled for position " + position + " for " + shift + " on " + day)
    for i in schedule:
        tk.Label(frm, text=i).pack()
    close_button = Button(frm, text="Back", command=root.destroy).pack()
    #auto_schedule to export to different file. Currently rtf doc.
    def auto_schedule():
        scheduled = Object()
        scheduled = schedule
    #create save file
        with open(AUTO_SCHEDULE, mode="w", encoding='utf-8') as jason_file:
            json.dump(scheduled, jason_file)
    commit_button = Button(frm, text="Commit Changes", command=auto_schedule).pack()
    #warning to double check. Hopefully can remove when I've refined selection process.
    warning = Label(frm, text="Warning: Be sure to double check any auto generated schedule before publishing.", foreground="#D20103").pack()
    #want to create button that publishes schedule here. Probably need to link to external source like excel.
    root.mainloop()
#show available button, links to def load_frame2()
myButton1 = Button(root, text="Show Availability", justify="left", background="#CECECE", cursor="hand2", activebackground="#808b96", command=load_frame2).grid(row=3, column=0)
#auto generate schedule button, links to def load_frame3()
myButton2 = Button(root, text="Generate Schedule", justify="left", background="#CECECE", cursor="hand2", activebackground="#808b96", command=load_frame3).grid(row=3, column=1)
#warning to double check. Hopefully can remove when I've refined selection process.
warning = Label(root, text="Warning: Be sure to double check any auto generated schedule before publishing.", font="15", foreground="#D20103").grid(column=4, row=5)
root.mainloop()
connection.close()

#want to create program that lets you alter 'Schedule' database or connect to external program to fetch data.