import tkinter as tk
from tkinter import *
from tkinter import ttk
import sqlite3
import random
import json
from tkinter.filedialog import asksaveasfile

#Frame1
#This file lets you search for a particular day/shift/position combo.
#may want to include either entry box or drop down on frame 2 to fill in schedule as you go.
#Want to expand to include entire week/day
#still need to clean up windows a bit and include an export function to publish generated schedule.
class Object:
    def toJSON(self):
        return json.dumps(
            self,
            default=lambda o: o.__dict__, 
            sort_keys=True,
            indent=4)

AUTO_SCHEDULE = "auto_schedule.rtf"

root = tk.Tk()
root.title("Scheduler")
root.geometry("1000x500")
root.eval("tk::PlaceWindow . center")


#created a def for each drop down choice
def display_choice1(choice1):
    choice1 = day_selected.get()
    #print(choice1)
def display_choice2(choice2):
    choice2 = shift_selected.get()
    #print(choice2)
def display_choice3(choice3):
    choice3 = position_selected.get()
    #print(choice3)
connection = sqlite3.connect("Schedule.db")
cursor_1 = connection.cursor()
cursor_2 = connection.cursor()
cursor_3 = connection.cursor()

cursor_1.execute("SELECT DISTINCT day_available FROM Employee")
cursor_2.execute("SELECT DISTINCT shift_available FROM Employee")
cursor_3.execute("SELECT DISTINCT position FROM Employee")

day_available = cursor_1.fetchall()
shift_available = cursor_2.fetchall()
position = cursor_3.fetchall()


options_day=[]
for i in day_available:
    day= i[0]
    options_day.append(day)
dow=sorted(options_day)

options_shift=[]
for i in shift_available:
    shift= i[0]
    options_shift.append(shift)
shift_worked=sorted(options_shift)

options_position=[]
for i in position:
    position= i[0]
    options_position.append(position)
position_worked=sorted(options_position)

day_selected = tk.StringVar()
day_selected.set("Select Day")
#don't forget * to make days separate
drop_day = OptionMenu(root, day_selected, *dow, command=display_choice1).grid(row=0, column= 0)

shift_selected = tk.StringVar()
shift_selected.set("Select Shift")
#don't forget * to make days separate
drop_shift = OptionMenu(root, shift_selected, *shift_worked, command=display_choice2).grid(row=0, column=1)

position_selected = tk.StringVar()
position_selected.set("Select Position")
#don't forget * to make days separate
drop_position = OptionMenu(root, position_selected, *position_worked, command=display_choice3).grid(row=0, column=2)

def load_frame2():
    root = tk.Tk()
    root.title("Scheduler")
    root.geometry("1000x500")
    root.eval("tk::PlaceWindow . center")

    # frm = tk.Frame(root, height= 500, width= 500)
    # frm.grid(row=0, column=0)
    # frm.pack_propagate(False)
    
    cursor=connection.cursor()
    cursor.execute("SELECT * FROM Week WHERE position LIKE ? AND day LIKE ? AND shift LIKE ?", ('%' + str(position_selected.get()) + '%', '%' + str(day_selected.get()) + '%', '%' + str(shift_selected.get()) + '%'))
    needed =cursor.fetchall()
    #index list needed and create object num
    for i in needed:
        day = i[0]
        shift = i[1]
        position = i[2]
        num = i[3]
    
    
    cursor.execute("SELECT * FROM Employee WHERE position LIKE ? AND day_available LIKE ? AND shift_available LIKE ?", ('%' + str(position_selected.get()) + '%', '%' + str(day_selected.get()) + '%', '%' + str(shift_selected.get()) + '%'))
    available=cursor.fetchall()
    #use k=num to auto pull number of people needed
    #random.sample should provide unique names
    
    schedule=[]
#append list 'schedule' to be more user friendly
    for i in available:
        id = i[0]
        name = i[1]
        position = i[2]
        day = i[3]
        shift = i[4]
        schedule.append(name + " can work " + position + " for " + shift + " on " + day)
    for i in schedule:
        tk.Label(root, text=i).pack()
    #auto_schedule to export to different file. Currently rtf doc.
    
    my_schedule = []
    
    def current_schedule():
        entry_list = ""
        for i in my_schedule:
            entry_list = entry_list + str(i.get()) + '\n'
            my_label.config(text=entry_list)

    def writeToJSONFile(path, fileName, data):
        json.dump(data, path)
    path ='./' 
    def check():
        entry_list = ""
        for i in my_schedule:
            entry_list = entry_list + str(i.get()) + " is scheduled for " + position + " for " + shift + " on " + day + ". "
            #lines = '\n'.join(my_schedule) trying to get new line for each entry
            my_label.config(text=entry_list)
            a = str(i.get())
            print(a)
        
            # print(export_list)
        # data = {}
        # data['Name']=a
        # data['Day']=day
        # data['Shift']=shift
        # data['Position']=position
        scheduled = Object()
        scheduled = entry_list
        files = [('JSON File', '.rtf')]
        fileName = 'Schedule'
        filepos = asksaveasfile(filetypes=files, defaultextension=json,initialfile='Schedule')
        writeToJSONFile(filepos, fileName, scheduled)
    for x in range(num):
        name_box = Entry(root)
        name_box.pack()
        my_schedule.append(name_box)
    
    generate_button = Button(root, text="Show Schedule", command=check).pack()
    close_button = Button(root, text="Back", command=root.destroy).pack()
    my_label = Label(root, text=" ")
    my_label.pack()
    root.mainloop()
def load_frame3():
    #initially intended to launch new window, but accidentally got it working in original
    root = tk.Tk()
    root.title("Scheduler")
    root.geometry("1000x500")
    root.eval("tk::PlaceWindow . center")

    frm = tk.Frame(root, height= 500, width= 500)
    frm.grid(row=0, column=0)
    frm.pack_propagate(False)
    
    cursor=connection.cursor()
    cursor.execute("SELECT * FROM Week WHERE position LIKE ? AND day LIKE ? AND shift LIKE ?", ('%' + str(position_selected.get()) + '%', '%' + str(day_selected.get()) + '%', '%' + str(shift_selected.get()) + '%'))
    needed =cursor.fetchall()
    #index list needed and create object num
    for i in needed:
        day = i[0]
        shift = i[1]
        position = i[2]
        num = i[3]
    
    
    cursor.execute("SELECT * FROM Employee WHERE position LIKE ? AND day_available LIKE ? AND shift_available LIKE ?", ('%' + str(position_selected.get()) + '%', '%' + str(day_selected.get()) + '%', '%' + str(shift_selected.get()) + '%'))
    available=cursor.fetchall()
    #use k=num to auto pull number of people needed
    #random.sample should provide unique names
    team = random.sample(available, k=num)
    schedule=[]
#append list 'schedule' to be more user friendly
    for i in team:
        id = i[0]
        name = i[1]
        position = i[2]
        day = i[3]
        shift = i[4]
        schedule.append(name + " is scheduled for position " + position + " for " + shift + " on " + day)
    for i in schedule:
        tk.Label(frm, text=i).pack()
    close_button = Button(frm, text="Back", command=root.destroy).pack()
    #auto_schedule to export to different file. Currently rtf doc.
    def auto_schedule():
        scheduled = Object()
        scheduled = schedule
    
        with open(AUTO_SCHEDULE, mode="w", encoding='utf-8') as jason_file:
            json.dump(scheduled, jason_file)
    commit_button = Button(frm, text="Commit Changes", command=auto_schedule).pack()
    #warning to double check. Hopefully can remove when I've refined selection process.
    warning = Label(frm, text="Warning: Be sure to double check any auto generated schedule before publishing.", foreground="#D20103").pack()
    #want to create button that publishes schedule here. Probably need to link to external source like excel.
    root.mainloop()
#show available button, links to def load_frame2()
myButton1 = Button(root, text="Show Availability", justify="left", background="#CECECE", cursor="hand2", activebackground="#808b96", command=load_frame2).grid(row=3, column=0)
#auto generate schedule button, links to def load_frame3()
myButton2 = Button(root, text="Generate Schedule", justify="left", background="#CECECE", cursor="hand2", activebackground="#808b96", command=load_frame3).grid(row=3, column=1)
#warning to double check. Hopefully can remove when I've refined selection process.
warning = Label(root, text="Warning: Be sure to double check any auto generated schedule before publishing.", font="15", foreground="#D20103").grid(column=4, row=5)
root.mainloop()
connection.close()

#want to create program that lets you alter 'Schedule' database or connect to external program to fetch data.